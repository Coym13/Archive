import tkinter as tk
from tkinter import messagebox

# Função que calcula a soma dos dois números
def somar():
    try:
        # Obtém os valores dos campos de entrada e converte-os para float
        num1 = float(entry1.get())  # Primeiro número (campo entry1)
        num2 = float(entry2.get())  # Segundo número (campo entry2)
        
        # Calcula a soma dos dois números
        resultado = num1 + num2
        
        # Atualiza o label do resultado com o valor da soma
        label_result.config(text=f"Resultado: {resultado}")
    except ValueError:
        # Mostra uma mensagem de erro caso as entradas não sejam números válidos
        messagebox.showerror("Erro", "Por favor, insira números válidos.")

# Cria a janela principal da interface
root = tk.Tk()
root.title("Soma de Dois Números")  # Define o título da janela

# Criação do primeiro label (rótulo) para o campo "Número 1"
label1 = tk.Label(root, text="Número 1:")
label1.pack(pady=5)  # O parâmetro `pady=5` adiciona 5 pixels de espaço vertical (padding) acima e abaixo do rótulo

# Criação do primeiro campo de entrada de texto (onde o usuário digita o primeiro número)
entry1 = tk.Entry(root)
entry1.pack(pady=5)  # Adiciona 5 pixels de espaço vertical acima e abaixo do campo de texto

# Criação do segundo label (rótulo) para o campo "Número 2"
label2 = tk.Label(root, text="Número 2:")
label2.pack(pady=5)  # Adiciona 5 pixels de espaço vertical para separação

# Criação do segundo campo de entrada de texto (onde o usuário digita o segundo número)
entry2 = tk.Entry(root)
entry2.pack(pady=5)  # Adiciona 5 pixels de espaço vertical acima e abaixo do campo de texto

# Criação do botão "Somar", que chama a função `somar` quando pressionado
button_somar = tk.Button(root, text="Somar", command=somar)
button_somar.pack(pady=10)  # `pady=10` adiciona 10 pixels de espaço vertical em volta do botão, para dar mais espaçamento

# Criação do rótulo que mostrará o resultado da soma dos números
label_result = tk.Label(root, text="Resultado: ")
label_result.pack(pady=10)  # `pady=10` adiciona 10 pixels de espaço vertical para separar o rótulo dos outros elementos

# Inicia o loop principal da interface gráfica, mantendo a janela aberta e interativa
root.mainloop()
