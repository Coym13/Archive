<?php 
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT); 
  
if ($id === false || $id === null || $id <= 0) { 
    http_response_code(400); 
    exit('Código de produto inválido.'); 
} 
  
require 'conexao.php'; 
$sql = 'SELECT id, nome, preco, quantidade FROM produtos WHERE id = ?'; 
$comando = mysqli_prepare($conexao, $sql); 
  
if ($comando === false) { 
    exit('Erro ao preparar a consulta.'); 
} 
  
mysqli_stmt_bind_param($comando, 'i', $id); 
mysqli_stmt_execute($comando); 
$resultado = mysqli_stmt_get_result($comando); 
  
if ($resultado === false) { 
    exit('Erro ao consultar o produto.'); 
} 
$produto = mysqli_fetch_assoc($resultado); 
if ($produto === null) { 
    http_response_code(404); 
    exit('Produto não encontrado.'); 
} 
  
mysqli_free_result($resultado); 
mysqli_stmt_close($comando); 
mysqli_close($conexao); 
?> 
<!DOCTYPE html> 
<html lang="pt-br"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <title>Editar Produto</title> 
    <link rel="stylesheet" href="estilo.css"> 
</head> 
<body> 
<main class="container pequeno"> 
    <h1>Editar produto</h1> 
    <form method="post" action="atualizar.php" class="formulario"> 
        <input type="hidden" name="id" 
               value="<?php echo (int) $produto['id']; ?>"> 
  
        <label for="nome">Nome</label> 
        <input id="nome" name="nome" type="text" maxlength="100" required 
               value="<?php echo htmlspecialchars( 
                   $produto['nome'], ENT_QUOTES, 'UTF-8' 
               ); ?>"> 
  
        <label for="preco">Preço (R$)</label> 
        <input id="preco" name="preco" type="number" step="0.01" min="0" 
               required value="<?php echo $produto['preco']; ?>"> 
  
        <label for="quantidade">Quantidade</label> 
        <input id="quantidade" name="quantidade" type="number" 
               step="1" min="0" required 
               value="<?php echo (int) $produto['quantidade']; ?>"> 
  
        <button type="submit">Gravar alterações</button> 
    </form> 
    <p><a href="index.php">Cancelar e voltar</a></p> 
</main> 
</body> 
</html> 