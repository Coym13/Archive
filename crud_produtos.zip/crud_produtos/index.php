<?php 
require 'conexao.php'; 
  
$sql = 'SELECT id, nome, preco, quantidade FROM produtos ORDER BY id DESC'; 
$resultado = mysqli_query($conexao, $sql); 
  
if ($resultado === false) { 
    exit('Erro ao consultar a lista de produtos.'); 
} 
  
$avisos = [ 
    'cadastrado' => 'Produto cadastrado!', 
    'atualizado' => 'Produto atualizado!', 
    'excluido' => 'Produto excluído!' 
]; 
$mensagem = $_GET['mensagem'] ?? ''; 
?> 
<!DOCTYPE html> 
<html lang="pt-br"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <title>Cadastro de Produtos</title> 
    <link rel="stylesheet" href="estilo.css"> 
</head> 
<body> 
<main class="container"> 
    <h1>Cadastro de Produtos</h1> 
    <p>Exemplo de CRUD com PHP e MySQLi procedural.</p> 
    <p><a class="botao" href="cadastrar.php">Novo produto</a></p> 
  
    <?php if (isset($avisos[$mensagem])): ?> 
        <p class="sucesso"><?php echo $avisos[$mensagem]; ?></p> 
    <?php endif; ?> 
  
    <?php if (mysqli_num_rows($resultado) === 0): ?> 
        <p>Nenhum produto cadastrado.</p> 
    <?php else: ?> 
        <div class="tabela-rolagem"> 
        <table> 
            <thead> 
                <tr> 
                    <th>ID</th><th>Nome</th><th>Preço</th> 
                    <th>Quantidade</th><th>Ações</th> 
                </tr> 
            </thead> 
            <tbody> 
            <?php while ($produto = mysqli_fetch_assoc($resultado)): ?> 
                <tr> 
                    <td><?php echo (int) $produto['id']; ?></td> 
                    <td><?php echo htmlspecialchars( 
                        $produto['nome'], ENT_QUOTES, 'UTF-8' 
                    ); ?></td> 
                    <td>R$ <?php echo number_format( 
                        (float) $produto['preco'], 2, ',', '.' 
                    ); ?></td> 
                    <td><?php echo (int) $produto['quantidade']; ?></td> 
                    <td class="acoes"> 
                        <a href="editar.php?id=<?php echo (int) $produto['id']; ?>"> 
                            Editar 
                        </a> 
                        <form method="post" action="excluir.php" 
                              onsubmit="return confirm('Excluir este produto?');"> 
                            <input type="hidden" name="id" 
                                   value="<?php echo (int) $produto['id']; ?>"> 
                            <button type="submit" class="perigo">Excluir</button> 
                        </form> 
                    </td> 
                </tr> 
            <?php endwhile; ?> 
            </tbody> 
        </table> 
        </div> 
    <?php endif; ?> 
</main> 
</body> 
</html> 
<?php 
mysqli_free_result($resultado); 
mysqli_close($conexao); 