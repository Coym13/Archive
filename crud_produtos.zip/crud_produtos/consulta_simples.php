<?php 
require 'conexao.php'; 
$sql = 'SELECT id, nome, preco, quantidade FROM produtos'; 
$resultado = mysqli_query($conexao, $sql); 
if ($resultado === false) { 
exit('Falha ao consultar os produtos.'); 
} 
while ($produto = mysqli_fetch_assoc($resultado)) { 
echo htmlspecialchars($produto['nome'], ENT_QUOTES, 'UTF-8') . '<br>'; 
}mysqli_free_result($resultado); 
mysqli_close($conexao);
?>