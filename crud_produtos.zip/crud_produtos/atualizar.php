<?php 
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
    header('Location: index.php'); 
    exit; 
} 
  
$id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT); 
$nome = trim($_POST['nome'] ?? ''); 
$precoTexto = $_POST['preco'] ?? ''; 
$quantidadeTexto = $_POST['quantidade'] ?? ''; 
$quantidade = filter_var($quantidadeTexto, FILTER_VALIDATE_INT); 
  
if ($id === false || $id <= 0 || 
    $nome === '' || strlen($nome) > 100 || 
    !is_numeric($precoTexto) || 
    (float) $precoTexto < 0 || (float) $precoTexto > 99999999.99 || 
    $quantidade === false || $quantidade < 0) { 
    exit('Dados inválidos. Volte ao formulário e corrija-os.'); 
} 
  
$preco = (float) $precoTexto; 
require 'conexao.php'; 
  
$sql = 'UPDATE produtos SET nome = ?, preco = ?, quantidade = ? WHERE id = ?'; 
$comando = mysqli_prepare($conexao, $sql); 
  
if ($comando === false) { 
    exit('Não foi possível preparar a atualização.'); 
} 
  
mysqli_stmt_bind_param($comando, 'sdii', $nome, $preco, $quantidade, $id); 
  
if (!mysqli_stmt_execute($comando)) { 
    exit('Não foi possível atualizar o produto.'); 
} 
  
mysqli_stmt_close($comando); 
mysqli_close($conexao); 
header('Location: index.php?mensagem=atualizado'); 
exit; 