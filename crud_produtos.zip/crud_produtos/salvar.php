<?php 
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
    header('Location: cadastrar.php'); 
    exit; 
} 
  
$nome = trim($_POST['nome'] ?? ''); 
$precoTexto = $_POST['preco'] ?? ''; 
$quantidadeTexto = $_POST['quantidade'] ?? ''; 
$quantidade = filter_var($quantidadeTexto, FILTER_VALIDATE_INT); 
  
if ($nome === '' || strlen($nome) > 100 || 
    !is_numeric($precoTexto) || 
    (float) $precoTexto < 0 || (float) $precoTexto > 99999999.99 || 
    $quantidade === false || $quantidade < 0) { 
    exit('Dados inválidos. Volte ao formulário e corrija-os.'); 
} 
  
$preco = (float) $precoTexto; 
require 'conexao.php'; 
  
$sql = 'INSERT INTO produtos (nome, preco, quantidade) VALUES (?, ?, ?)'; 
$comando = mysqli_prepare($conexao, $sql); 
  
if ($comando === false) { 
    exit('Não foi possível preparar o cadastro.'); 
} 
  
mysqli_stmt_bind_param($comando, 'sdi', $nome, $preco, $quantidade); 
  
if (!mysqli_stmt_execute($comando)) { 
    exit('Não foi possível cadastrar o produto.'); 
} 
  
mysqli_stmt_close($comando); 
mysqli_close($conexao); 
header('Location: index.php?mensagem=cadastrado'); 
exit;