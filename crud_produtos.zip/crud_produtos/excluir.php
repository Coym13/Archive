<?php 
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
    header('Location: index.php'); 
    exit; 
} 
  
$id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT); 
if ($id === false || $id <= 0) { 
    exit('Código de produto inválido.'); 
} 
  
require 'conexao.php'; 
$sql = 'DELETE FROM produtos WHERE id = ?'; 
$comando = mysqli_prepare($conexao, $sql); 
if ($comando === false) { 
    exit('Não foi possível preparar a exclusão.'); 
} 
  
mysqli_stmt_bind_param($comando, 'i', $id); 
  
if (!mysqli_stmt_execute($comando)) { 
    exit('Não foi possível excluir o produto.'); 
} 
  
mysqli_stmt_close($comando); 
mysqli_close($conexao); 
header('Location: index.php?mensagem=excluido'); 
exit; 