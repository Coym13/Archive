<!DOCTYPE html> 
<html lang="pt-br"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <title>Cadastrar Produto</title> 
    <link rel="stylesheet" href="estilo.css"> 
</head> 
<body> 
<main class="container pequeno"> 
    <h1>Cadastrar produto</h1> 
    <form method="post" action="salvar.php" class="formulario"> 
        <label for="nome">Nome</label> 
        <input id="nome" name="nome" type="text" maxlength="100" required> 
        <label for="preco">Preço (R$)</label> 
        <input id="preco" name="preco" type="number" 
               min="0" step="0.01" required> 
  
        <label for="quantidade">Quantidade</label> 
        <input id="quantidade" name="quantidade" type="number" 
               min="0" step="1" required> 
  
        <button type="submit">Salvar produto</button> 
    </form> 
    <p><a href="index.php">Voltar à lista</a></p> 
</main> 
</body> 
</html> 