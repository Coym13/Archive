<?php 
// Configuração apenas para uso local no XAMPP. 
$servidor = 'localhost'; 
$usuario = 'root'; 
$senha = ''; 
$banco = 'aula_php_crud'; 
// Permite verificar falhas com if, de forma didática. 
mysqli_report(MYSQLI_REPORT_OFF); 
$conexao = mysqli_connect($servidor, $usuario, $senha, $banco); 
if (!$conexao) { 
http_response_code(500); 
exit('Falha ao conectar. Verifique o XAMPP e o banco.'); 
} 
if (!mysqli_set_charset($conexao, 'utf8mb4')) { 
mysqli_close($conexao); 
exit('Não foi possível configurar UTF-8.'); 
}
